+ Response 401
    Authentication failed. Please read about [authentication](#authentication) process.
    + Body